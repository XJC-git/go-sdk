for ((i=1; i<=250; i ++))
do
	./hmy keys add $i
    echo $i
done