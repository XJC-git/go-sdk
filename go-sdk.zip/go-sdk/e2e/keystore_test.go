package keys

import (
	"fmt"
	"testing"
)

func TestKeyStore(t *testing.T) {
	fmt.Println("Hello world")
	//t.Errorf("Testing pipeline")
}
