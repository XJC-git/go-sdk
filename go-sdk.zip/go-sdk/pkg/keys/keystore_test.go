package keys

import (
	"fmt"
	"testing"
)

func TestKeyStore(t *testing.T) {
	fmt.Println("Hello world 3")
	// t.Errorf("Testing pipeline")
}

func TestAnother(t *testing.T) {
	fmt.Println("Another test run")
}
