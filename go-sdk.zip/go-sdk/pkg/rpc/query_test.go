package rpc

import (
	"fmt"
	"testing"
)

func TestRPCRequest(t *testing.T) {
	fmt.Println("hell rpc?")
}
